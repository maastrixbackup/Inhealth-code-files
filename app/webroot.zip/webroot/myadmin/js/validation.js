// JavaScript Document
$(document).ready(function(e) {
	
	$("#addadmnFrm").submit(function(e) {
		var fname=$("#MasterAdmin_fname").val();
		var phone=$("#MasterAdmin_phone").val();
		var email=$("#MasterAdmin_email").val();
		var uname=$("#MasterAdmin_uname").val();
		var pwd=$("#MasterAdmin_pwd").val();
		var filter=/^\s*[\w\-\+_]+(\.[\w\-\+_]+)*\@[\w\-\+_]+\.[\w\-\+_]+(\.[\w\-\+_]+)*\s*$/;
		if(fname==''){
			$("#MasterAdmin_fname").css("background-color", "#FFBCB3");
			$("#MasterAdmin_fname").focus();
			return false;
		}else{
			$("#MasterAdmin_fname").css("background-color", "");
		}
		if(email==''){
			$("#MasterAdmin_email").css("background-color", "#FFBCB3");
			$("#MasterAdmin_email").focus();
			return false;
		}else if(!filter.test(email)){
			$("#MasterAdmin_email").css("background-color", "#FFBCB3");
			$("#MasterAdmin_email").focus();
			return false;
		}else{
			$("#MasterAdmin_email").css("background-color", "");
		}
		if(phone==''){
			$("#MasterAdmin_phone").css("background-color", "#FFBCB3");
			$("#MasterAdmin_phone").focus();
			return false;
		}else{
			$("#MasterAdmin_phone").css("background-color", "");
		}
		
		if(uname==''){
			$("#MasterAdmin_uname").css("background-color", "#FFBCB3");
			$("#MasterAdmin_uname").focus();
			return false;
		}else{
			$("#MasterAdmin_uname").css("background-color", "");
		}
		if(pwd==''){
			$("#MasterAdmin_pwd").css("background-color", "#FFBCB3");
			$("#MasterAdmin_pwd").focus();
			return false;
		}else{
			$("#MasterAdmin_pwd").css("background-color", "");
		}
	});

	$("#MasterUserCountry").change(function(){
		$.ajax({
			type: "POST",
			url: jsBaseUrl+"admin/MasterUsers/getstate",
			data: "countryID="+$(this).val(),
			success: function(data){
				if(data){
					$("#MasterUserState").html(data);
				}
			}
		});
	});
});
function isNumberKey(evt) {
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		// Added to allow decimal, period, or delete
		//alert(charCode);
		if (charCode !=46 && charCode > 31 && (charCode < 48 || charCode > 57)) 
			return false;
		
		return true;
	}
	function onlyNumberKey(evt) {
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		// Added to allow decimal, period, or delete
		//alert(charCode);
		if (charCode > 31 && (charCode < 48 || charCode > 57)) 
			return false;
		
		return true;
	}
	